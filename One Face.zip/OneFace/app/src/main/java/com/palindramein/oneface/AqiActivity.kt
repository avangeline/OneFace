package com.palindramein.oneface

import android.os.Bundle
import android.support.wearable.activity.WearableActivity

class AqiActivity : WearableActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aqi)
    }

    private fun getAirQualityIndex() {

    }
}
